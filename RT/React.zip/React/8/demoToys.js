const demoToys = [
    {title: 'Кукольный кот, плюшевая игрушка', price: 917, img: 'toys_1.jpg', id: 1},
    {title: 'Детские игрушки с авокадо', price: 591, img: 'toys_2.jpg', id: 2},
    {title: '23 см имитация маленького тигра', price: 594, img: 'toys_3.jpg', id: 3},
    {title: 'Мультяшный дракон, талисман', price: 364, img: 'toys_4.jpg', id: 4},
    {title: 'Плюшевая кукла с изображением тигра', price: 553, img: 'toys_5.jpg', id: 5},
    {title: 'Милый медведь, мультяшная подушка', price: 273, img: 'toys_6.jpg', id: 6},
]

export default demoToys;